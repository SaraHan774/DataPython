# -*- coding: utf-8 -*-
"""
Created on Thu Dec 27 15:27:39 2018

@author: GAHEE HAN
"""
from konlpy.tag import Twitter
from collections import Counter
import re 
import pandas as pd

fr = open("donga_comment_313.txt", "rb").read().decode('utf-8')

kor_msg = re.compile('[^ㄱ-ㅣ가-힣0-9]+')
kor_msg_result = kor_msg.sub(' ',fr)

with open("donga_comment.txt", 'w', encoding = 'utf-8') as file:
    file.write(kor_msg_result)

nlp = Twitter()
nouns = nlp.nouns(kor_msg_result)
count = Counter(nouns)

wordInfo = { }
for tags, counts in count.most_common(50):
    if(len(str(tags)) > 1):
        wordInfo[tags] = counts
        print("%s : %d" %(tags, counts))
        
wordInfo2 = {"빈도수" : wordInfo}
datafr = pd.DataFrame(wordInfo2).to_csv("donga_comment_313.csv", index = True, encoding = 'ms949' )
