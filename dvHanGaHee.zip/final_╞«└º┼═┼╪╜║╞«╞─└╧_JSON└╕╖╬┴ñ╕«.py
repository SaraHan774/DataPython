# -*- coding: utf-8 -*-
"""
Created on Wed Dec 26 15:44:51 2018

@author: GAHEE HAN
"""

import json

text = open('tweets_minimum_full.txt',"r", encoding = 'utf-8').read()
RT_removed = text.split("RT ")


dict_txt = {"user_id" : "", "text" : ""}

for i in RT_removed:
    try:
        col_removed = i.split(":")    
        if(len(col_removed) >=3):
            dict_txt["user_id"] = [col_removed[0]]
            dict_txt["text"] = [col_removed[1]]
            dict_txt["text_a"] = [col_removed[2:]]
        else:
            dict_txt["user_id"] = [col_removed[0]]
            dict_txt["text"] = [col_removed[1]]
        
        jsonstr = json.dumps(dict_txt, ensure_ascii=False, indent=True) + ","
        with open("jsonfile_minimum_wage_1.json", "a", encoding = "utf-8") as file:
            file.write(jsonstr) #다만 수동으로 텍스트의 가장 끝에 생기는 ","를 제거하고 양 끝에 '['와  ']'를 삽입해야 함
    except IndexError as e:
        print(e)
        continue
    
