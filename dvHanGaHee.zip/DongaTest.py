# -*- coding: utf-8 -*-
"""
Created on Thu Dec 27 14:50:18 2018

@author: GAHEE HAN
"""

import bs4

with open("donga_comment.html", "rb") as file:
    fr = file.read().decode('utf-8')
    
soup = bs4.BeautifulSoup(fr)
tgs = soup.find("ul", {"class":"list_comment"})
tsg_p = tgs.findAll("p")

tgs_p_list = [] 

for i in tsg_p:
    tgs_text = tgs_p_list.append(i.get_text())
    print(len(tgs_p_list), ":", i.get_text())

with open("donga_comment_313.txt", "w", encoding = 'utf-8') as file:
    file.write(str(tgs_p_list))