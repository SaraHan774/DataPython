# -*- coding: utf-8 -*-
"""
Created on Sat Dec 22 14:57:44 2018

@author: GAHEE HAN
"""

from tweepy.streaming import StreamListener
from tweepy import OAuthHandler
from tweepy import Stream


class MyStreamListener(StreamListener): #StreamListener overriding
    def on_status(self, status):
        print(status.text)
        strtweet = status.text + "\n"
        with open("tweets_minimum_full.txt", "a" , encoding = 'utf-8') as file:
            file.write(strtweet)
   
    def on_error(self,status_code):
        if status_code ==420:
            #returning False in on_data disconnects the stream 
            return False

auth = OAuthHandler("BwDyL4IAzdsACHFgzJxUYXu7h", "9rWvm8iYIqitO39Z6CY0R0cz8zm6Dzd8OuLPGrVYLD35gzOYna")
auth.set_access_token("1044279985878384640-iVgOejUEQXDwKVwH6khu63rhx9ztZF", "y7t9yeVatifboshiLwpFt9sqK9EsBtrsVlT4SNQrYqFPJ")


myStreamListener = MyStreamListener()
myStream = Stream(auth, listener = myStreamListener, tweet_mode = 'extended')
trackList = ['최저임금']
myStream.filter(track = trackList, languages = ['ko'])





