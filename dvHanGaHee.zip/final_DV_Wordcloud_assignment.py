# -*- coding: utf-8 -*-
"""
Created on Tue Dec 11 18:57:03 2018

@author: GAHEE HAN
"""

from matplotlib import font_manager
import matplotlib.pyplot as plt
import pandas as pd
import pytagcloud 
from konlpy.tag import Twitter 
import json
import codecs
from collections import Counter
import re 
import webbrowser


#READ JSON FILE 
jsonfile = 'jsonfile_minimum_wage_1.json'
rfile = codecs.open(jsonfile, 'r', encoding = 'utf-8-sig').read()
jsonData = json.loads(rfile)

#MAKE VALUES OF 'text'KEY INTO ONE STRING 
message = ''

for items in range(len(jsonData)):
    message = message + str(jsonData[items]['text']) + str(jsonData[items]['text_a'])
    #+ str(jsonData[items]['text_a'])
#USING REGULAR EXPRESSION TO ONLY LEAVE ALPHANUMERICS AND BLANK SPACE
kor_msg = re.compile('[^ㄱ-ㅣ가-힣0-9]+')
kor_msg_result = kor_msg.sub(' ',message)

#SAVING "STRING.TXT" JUST TO CHECK THE RE.COMPLIE() RESULT
with open("string.txt", 'w', encoding = 'utf-8') as file:
    file.write(kor_msg_result)

#TWITTER OBJECT / NOUNS() METHOD / COUNTER IMPORTED FROM COLLECTIONS
nlp = Twitter()
nouns = nlp.nouns(kor_msg_result)
count = Counter(nouns)

#COUNT.MOST_COMMON(50) MUST RETURN AN ITERABLE...
wordInfo = { }
for tags, counts in count.most_common(50):
    if(len(str(tags)) > 1):
        wordInfo[tags] = counts
        print("%s : %d" %(tags, counts))


#FONT PATH
font_location = "c:/Windows/fonts/NanumGothic.ttf"
font_family = font_manager.FontProperties(fname=font_location).get_name()
#get_name(): Return the name of the font that best matches the font properties.
plt.rcParams["font.family"] = font_family
print(font_family) #RETURNS 'NanumGothic' 

#MAKING ANOTHER DICT THAT CONTAINS HEADER "빈도수"
wordInfo_head = {"빈도수" : wordInfo}

#MAKING BAR GRAPH USING PANDAS ADN MATPLOTLIB.PYPLOT/ DICT IS THE NEWLY MADE ONE.
twdata = pd.DataFrame(wordInfo_head)
twdata.plot(kind='bar') 
plt.xlabel('주요 단어') 
plt.ylabel('빈도수')
plt.show()

#MAKING CSV FILE USING PANDAS ".to_csv" METHOD
twdata.to_csv("minimum_wage_opinion.csv", index = True, encoding = 'ms949')

#MAKING PIE GRAPH USING MATPLOTLIB
labels = list(wordInfo.keys())
sizes = list(wordInfo.values())
fig1, ax1 = plt.subplots()
ax1.pie(sizes, labels = labels, startangle = 90, shadow = True, autopct='%1.1f%%', labeldistance = 2)
ax1.axis('equal')
plt.show()

#MAKING WORDCLOUD PNG FILE
maketag = pytagcloud.make_tags(wordInfo.items(), maxsize = 80)
filename = 'wordCloud.png'
pytagcloud.create_tag_image(maketag, filename, fontname = "Nanum Gothic", size = (800,600), rectangular=True)
webbrowser.open(filename)